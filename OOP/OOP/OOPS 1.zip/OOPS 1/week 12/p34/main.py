# main34.py
from p34 import SentenceWriter

def main():
    sw = SentenceWriter()
    sw.write_sentence("I will never spam my friends again.", 5)

if __name__ == "__main__":
    main()
